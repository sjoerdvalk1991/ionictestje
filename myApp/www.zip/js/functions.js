jQuery(document).ready(function($){

	$('.come-in').fadeIn( "fast", function (){
		console.log('testing');
	});
});

